# from django.contrib import admin
#
# from main_app.models import Employee, Department, Project
#
#
# # Register your models here.
# @admin.register(Employee)
# class Employee(admin.ModelAdmin):
#     pass
#
#
# @admin.register(Department)
# class Department(admin.ModelAdmin):
#     pass
#
#
# @admin.register(Project)
# class Project(admin.ModelAdmin):
#     pass
